﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adventure
{
    public static class Game
    {
        //character name
        static string CharacterName = "Anna De Luca";

        //print out game title and overview
        public static void StartGame()
        {
            Console.WriteLine("Welcome to...");
            Console.WriteLine("The Magnificent Mile: Zombie Apocolypse!");
            NameCharacter();
        }

        static void NameCharacter()
         {
            //ask player for a name, and save it
            Console.WriteLine("What would you like your characters name to be?");
            CharacterName = Console.ReadLine();

            Console.WriteLine("Great! Your character is now named: " + CharacterName);
         }
    }
}