﻿// The Magnificent Mile: Zombie Apocolypse 
// By Gianna G. Dimperio
// September 2022
// This is work derivative of "C# Adventure Game" by http://programmingisfun.com/learn/c-sharp-adventure-game/
using System;
namespace Adventure
{
    class Program
    {
        static void Main() // CS0017, delete one Main or use /main 
        {
            Game.StartGame();
            Console.ReadKey();
        }
    }
}

